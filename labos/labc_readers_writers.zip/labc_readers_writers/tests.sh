for i in {1..50}
do
    ./build/reader_writer 60 5 20
done > /dev/null

#include <linux/build-salt.h>
#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xedd9f090, "module_layout" },
	{ 0xd85efd38, "xnintr_detach" },
	{ 0xd650e268, "rtdm_irq_request" },
	{ 0xbc477a2, "irq_set_irq_type" },
	{ 0x1d228204, "gpiod_direction_output_raw" },
	{ 0xfe990052, "gpio_free" },
	{ 0x92bd2454, "gpiod_direction_input" },
	{ 0x47229b5c, "gpio_request" },
	{ 0x6db25ab6, "gpiod_to_irq" },
	{ 0x2e5810c6, "__aeabi_unwind_cpp_pr1" },
	{ 0x7c32d0f0, "printk" },
	{ 0x57c65e11, "gpiod_set_raw_value" },
	{ 0x4cb25550, "gpio_to_desc" },
	{ 0xb1ad28e0, "__gnu_mcount_nc" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "6C7DDBBAB1B39211FC941E0");
